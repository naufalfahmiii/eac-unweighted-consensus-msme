Semi-synthetic datasets for: Comparing Unweighted Consensus Functions for Clustering Mixed-Type MSME Data in East Java
======================================================================================================================

180 datasets = 3 separation sources (mixed, mainly_binary, mainly_numeric) x 3 separation levels (low, medium, high)
x true K (3, 4) x 10 replicates. Each file has n = 1,368 objects, the same size as the real registry.

Columns
  ID_OBJEK        object index 1..1368
  LAMA_USAHA, JUMLAH_TENAGA_KERJA, OMSET, BIAYA_PRODUKSI, GAJI_KARYAWAN, SERTIFIKASI_JUMLAH
                  numeric variables on their original scale (every value is a quantile of the real variable);
                  the analysis applies log1p to OMSET, BIAYA_PRODUKSI, GAJI_KARYAWAN, then Min-Max to all six
  PEMASARAN_ONLINE, KESULITAN_USAHA, NIB_STATUS
                  binary variables, 1 = YA (yes), 0 = TIDAK (no); marginal proportions follow the real data
  KELOMPOK_BENAR  generating (true) group, 1..K; group 1 is the largest.
                  Used only to score the clusterings (ARI, NMI); never given to any algorithm.

Generator (Gaussian copula)
  latent L = a * Z[group] + E, with a = a_num for the six numeric variables and a = a_bin for the three binary ones;
  Z = random group centres, E = standard normal noise carrying the real OMSET-BIAYA_PRODUKSI correlation
  (rho = 0.5627 on the log scale). Each latent column is standardised, then mapped to the empirical
  quantiles of the real variable (numeric) or thresholded at the real proportion (binary).
  Group proportions: K = 3 -> 66/20/14 %, K = 4 -> 60/20/13/7 %.
  Separation settings (a_num, a_bin):
    mixed          low (1.0, 1.0)  medium (1.5, 2.0)  high (3.5, 5.0)
    mainly_binary  low (0.3, 1.5)  medium (0.5, 3.0)  high (1.2, 8.0)
    mainly_numeric low (2.0, 0.0)  medium (4.0, 0.0)  high (6.0, 0.0)
  seed = 10000*(index of source in [mainly_binary, mainly_numeric, mixed] + 1) + 1000*level_index + 100*K + (replicate - 1)

daftar_dataset.csv lists every file with its condition, seed, a_num, a_bin and group sizes.
Notebook_Perbandingan_Fungsi_Konsensus_UMKM.ipynb (Sections 10 and 10B) regenerates every file exactly.
